// Task 2.3 - University hierarchy with virtual base class
#include <iostream>
#include <string>

class Person {
protected:
    std::string name; int id; std::string phone;
public:
    Person(std::string n = "", int i = 0, std::string p = "") : name(n), id(i), phone(p) {}
    virtual ~Person() = default;
};
class Student : public virtual Person {
protected:
    std::string programme; double cgpa;
public:
    Student(std::string n, int i, std::string p, std::string prog, double c)
        : Person(n, i, p), programme(prog), cgpa(c) {}
};
class Staff : public virtual Person {
protected:
    std::string dept; double salary;
public:
    Staff(std::string n, int i, std::string p, std::string d, double s)
        : Person(n, i, p), dept(d), salary(s) {}
};
class TeachingAssistant : public Student, public Staff {
public:
    TeachingAssistant(std::string n, int i, std::string p, std::string prog, double c,
                      std::string d, double s)
        : Person(n, i, p), Student(n, i, p, prog, c), Staff(n, i, p, d, s) {}
    void show() const { std::cout << name << ' ' << programme << ' ' << dept << '\n'; } // no ambiguity
};
class ResearchScholar : public Student {      // single inheritance
    double fellowship;
public:
    ResearchScholar(std::string n, int i, std::string p, std::string prog, double c, double f)
        : Person(n, i, p), Student(n, i, p, prog, c), fellowship(f) {}
};

int main() {
    TeachingAssistant ta("Divya", 7, "9876543210", "MCA", 8.7, "CSE", 25000);
    ta.show();
    std::cout << "sizeof(TA) = " << sizeof(ta) << '\n';
}
