// Task 4.1/4.2 - original defective program (instrumented). Run with -fsanitize=address
#include <iostream>
class Account { public: double rate() const { return 3.5; } ~Account() { std::cout << "~Account\n"; } };
class SeniorAccount : public Account {
    double* history = new double[100];
public:
    double rate() const { return 4.0; }
    ~SeniorAccount() { std::cout << "~SeniorAccount (frees history)\n"; delete[] history; }
};
int main() {
    Account* accounts[2] = { new Account, new SeniorAccount };
    for (Account* a : accounts) std::cout << a->rate() << "\n";   // prints 3.5 twice: static binding
    for (Account* a : accounts) delete a;                          // ~SeniorAccount never runs: leak
    Account copy = SeniorAccount();                                // slicing: derived part lost
    std::cout << copy.rate() << "\n";
}
