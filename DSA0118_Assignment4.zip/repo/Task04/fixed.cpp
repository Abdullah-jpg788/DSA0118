// Task 4.3 - repaired program
#include <iostream>
#include <memory>
#include <vector>
class Account {
public:
    virtual ~Account() { std::cout << "~Account\n"; }
    virtual double rate() const { return 3.5; }
};
class SeniorAccount : public Account {
    double* history = new double[100];
public:
    SeniorAccount() = default;
    SeniorAccount(const SeniorAccount&) = delete;            // rule of three: no shallow copy
    SeniorAccount& operator=(const SeniorAccount&) = delete;
    ~SeniorAccount() override { std::cout << "~SeniorAccount (frees history)\n"; delete[] history; }
    double rate() const override { return 4.0; }
};
int main() {
    std::vector<std::unique_ptr<Account>> accounts;
    accounts.push_back(std::make_unique<Account>());
    accounts.push_back(std::make_unique<SeniorAccount>());
    for (const auto& a : accounts) std::cout << a->rate() << "\n";   // 3.5, 4
    const Account& ref = *accounts[1];                                // reference, no copy
    std::cout << ref.rate() << "\n";
}   // unique_ptr deletes through the virtual destructor
