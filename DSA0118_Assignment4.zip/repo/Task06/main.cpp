#include "vehicles.h"
#include <memory>
#include <vector>

// NEW type added WITHOUT changing any existing class
class ElectricBus : public MotorVehicle {
    int seats_;
public:
    ElectricBus(std::string r, double d, Date s, int seats) : MotorVehicle(std::move(r), d, s), seats_(seats) {}
    double charge(int d) const override { return d * dailyRate_ + used_ * 18 + seats_ * 5; }
    std::string type() const override { return "ElectricBus"; }
};

int main() {
    std::vector<std::unique_ptr<Vehicle>> fleet;
    fleet.push_back(std::make_unique<Bicycle>("BI-01", 100));
    fleet.push_back(std::make_unique<TwoWheeler>("TN-11-1111", 400, Date(2026, 12, 1)));
    fleet.push_back(std::make_unique<Car>("TN-22-2222", 1500, Date(2027, 1, 15), 7));
    fleet.push_back(std::make_unique<ElectricCar>("TN-33-3333", 2000, Date(2027, 2, 1), 40));
    fleet.push_back(std::make_unique<ElectricBus>("TN-44-4444", 5000, Date(2027, 3, 1), 30));

    auto motor = [&](int i, double use) { dynamic_cast<MotorVehicle*>(fleet[i].get())->setUsage(use); };
    motor(1, 3); motor(2, 20); motor(3, 15); motor(4, 50);

    for (auto& v : fleet) { v->rent(); }
    std::cout << "--- Fleet ---\n";
    for (auto& v : fleet) { v->print(); std::cout << '\n'; }

    std::cout << "--- Returns (3 days allowed; second value = days kept) ---\n";
    int kept[5] = {3, 3, 3, 5, 3};                 // ElectricCar returned 2 days late
    for (int i = 0; i < 5; ++i)
        std::cout << fleet[i]->type() << ' ' << fleet[i]->regNo() << " charge = "
                  << fleet[i]->giveBack(kept[i], 3) << '\n';
}
