// Existing classes - never modified when new vehicle types are added
#pragma once
#include <algorithm>
#include <iostream>
#include <string>

class Date {                                   // member class (has-a)
    int y_, m_, d_;
public:
    Date(int y, int m, int d) : y_(y), m_(m), d_(d) {}
    std::string str() const { return std::to_string(y_) + "-" + std::to_string(m_) + "-" + std::to_string(d_); }
};

class Vehicle {                                // abstract base
protected:
    std::string regNo_; double dailyRate_; bool rented_ = false;
    static constexpr double LATE_FACTOR = 1.5; // late days cost 150% of daily rate
public:
    Vehicle(std::string r, double d) : regNo_(std::move(r)), dailyRate_(d) {}
    virtual ~Vehicle() = default;
    virtual double charge(int days) const = 0;           // pure virtual
    virtual std::string type() const = 0;
    virtual void print() const { std::cout << type() << ' ' << regNo_ << (rented_ ? " [rented]" : " [available]"); }
    bool rent() { if (rented_) return false; rented_ = true; return true; }
    double giveBack(int days, int allowed) {
        if (!rented_) return 0;
        rented_ = false;
        int late = std::max(0, days - allowed);
        return charge(allowed < days ? allowed : days) + late * dailyRate_ * LATE_FACTOR;
    }
    const std::string& regNo() const { return regNo_; }
};

class Bicycle : public Vehicle {
public:
    using Vehicle::Vehicle;
    double charge(int d) const override { return d * dailyRate_; }
    std::string type() const override { return "Bicycle"; }
};

class MotorVehicle : public Vehicle {          // abstract: still has pure virtuals
protected:
    double level_ = 100, used_ = 0; Date serviceDue_;
public:
    MotorVehicle(std::string r, double d, Date s) : Vehicle(std::move(r), d), serviceDue_(s) {}
    void setUsage(double u) { used_ = u; level_ -= u; }
    void print() const override { Vehicle::print(); std::cout << " service due " << serviceDue_.str(); }
};

class TwoWheeler : public MotorVehicle {
public:
    using MotorVehicle::MotorVehicle;
    double charge(int d) const override { return d * dailyRate_ + used_ * 100; }   // per litre
    std::string type() const override { return "TwoWheeler"; }
};

class Car : public MotorVehicle {
protected:
    int seats_;
public:
    Car(std::string r, double d, Date s, int seats) : MotorVehicle(std::move(r), d, s), seats_(seats) {}
    double charge(int d) const override { return d * dailyRate_ + used_ * 110 + (seats_ > 5 ? 200 : 0); }
    std::string type() const override { return "Car"; }
};

class ElectricCar : public MotorVehicle {
protected:
    double batteryKWh_;
public:
    ElectricCar(std::string r, double d, Date s, double b) : MotorVehicle(std::move(r), d, s), batteryKWh_(b) {}
    double charge(int d) const override { return d * dailyRate_ + used_ * 12; }    // per kWh
    std::string type() const override { return "ElectricCar"; }
};
