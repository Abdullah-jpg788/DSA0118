// Tasks 5.1 and 5.2
#include <iomanip>
#include <iostream>
#include <string>
class Cart {
    std::string items[10]; double prices[10]; int n = 0; double discount = 0;
public:
    Cart& add(const std::string& item, double price) {
        if (n < 10) { items[n] = item; prices[n] = price; ++n; }
        return *this;
    }
    Cart& setDiscount(double discount) { this->discount = discount; return *this; }
    double total() const {
        double t = 0; for (int i = 0; i < n; ++i) t += prices[i];
        return t * (100 - discount) / 100;
    }
};
void viaReference(Cart& r) { r.add("Milk", 50); }
int main() {
    std::cout << std::fixed << std::setprecision(2);
    Cart a;  a.add("Rice", 60).add("Dal", 120);                 // (a) by name
    std::cout << "a: " << a.total() << '\n';
    Cart* p = &a;  p->add("Oil", 180);                          // (b) pointer
    std::cout << "b: " << p->total() << '\n';
    viaReference(a);                                            // (c) reference
    std::cout << "c: " << a.total() << '\n';
    Cart* h = new Cart;  h->add("Tea", 90).setDiscount(5);      // (d) new / delete
    std::cout << "d: " << h->total() << '\n';
    delete h;

    // 5.2 array of pointers: find cart with highest total
    Cart* carts[3] = { new Cart, new Cart, new Cart };
    carts[0]->add("A", 100); carts[1]->add("B", 500); carts[2]->add("C", 300);
    Cart** best = carts;
    for (Cart** q = carts + 1; q < carts + 3; ++q)              // pointer arithmetic
        if ((*q)->total() > (*best)->total()) best = q;
    std::cout << "highest: cart " << (best - carts) << " total " << (*best)->total() << '\n';
    for (Cart* c : carts) delete c;
}
