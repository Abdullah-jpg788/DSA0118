// Task 1.2 - Repaired payroll hierarchy
#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Staff {                       // abstract base: common data + interface
    std::string name_;
    int id_;
protected:
    static constexpr double DA_RATE = 0.42;   // no magic number
public:
    Staff(std::string n, int i) : name_(std::move(n)), id_(i) {}
    virtual ~Staff() = default;
    virtual double pay() const = 0;           // overridden in each derived class
    const std::string& name() const { return name_; }
    int id() const { return id_; }
};

class Salaried : public Staff {             // shared rule: basic + DA
protected:
    double basic_;
public:
    Salaried(std::string n, int i, double b) : Staff(std::move(n), i), basic_(b) {}
    double pay() const override { return basic_ + basic_ * DA_RATE; }
};

class Professor : public Salaried {
    double research_;
public:
    Professor(std::string n, int i, double b, double r) : Salaried(std::move(n), i, b), research_(r) {}
    double pay() const override { return Salaried::pay() + research_; }
};

class LabAssistant : public Salaried {
public:
    using Salaried::Salaried;               // pay() inherited: basic + DA
};

class GuestFaculty : public Staff {
    double hours_, rate_;
public:
    GuestFaculty(std::string n, int i, double h, double r) : Staff(std::move(n), i), hours_(h), rate_(r) {}
    double pay() const override { return hours_ * rate_; }
};

int main() {
    std::vector<std::unique_ptr<Staff>> staff;
    staff.push_back(std::make_unique<Professor>("Dr. Rao", 1, 50000, 8000));
    staff.push_back(std::make_unique<LabAssistant>("Meena", 2, 20000));
    staff.push_back(std::make_unique<GuestFaculty>("Arun", 3, 40, 900));
    for (const auto& s : staff)             // one loop for all staff
        std::cout << s->id() << ' ' << s->name() << " pay = " << s->pay() << '\n';
}
