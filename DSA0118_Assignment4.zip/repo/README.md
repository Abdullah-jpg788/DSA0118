# DSA01 - Assignment 4 (CO4): Designing Reusable Class Hierarchies

- Name: <YOUR NAME>
- Register number: <YOUR REGISTER NUMBER>
- Compiler: g++ <version>   (check with `g++ --version`)
- Compile command: `g++ -std=c++17 -Wall -Wextra file.cpp -o file`
- Sanitizer (Task 4): `g++ -std=c++17 -g -fsanitize=address buggy.cpp -o buggy`

| Task | Folder | Files | How to run | Result |
|------|--------|-------|-----------|--------|
| 1 | Task01 | payroll.cpp | `g++ ... payroll.cpp -o payroll && ./payroll` | all staff paid in one loop |
| 2 | Task02 | university.cpp, predict_diamond.cpp | same pattern | Person constructed once |
| 3 | Task03 | ctor_trace.cpp, predict_order.cpp, complete_code.cpp | same pattern | Kavya line matches expected |
| 4 | Task04 | buggy.cpp, fixed.cpp, predict_slicing.cpp | same pattern | defects shown, then repaired |
| 5 | Task05 | cart_complete.cpp, cart_ways.cpp | same pattern | 324.00 |
| 6 | Task06 | vehicles.h, main.cpp | `g++ ... main.cpp -o fleet && ./fleet` | ElectricBus added without editing old classes |

Add your output screenshots (code + terminal) inside each task folder.
