// Tasks 3.1-3.4: constructor/destructor tracing with virtual base and member classes
#include <iostream>
#include <string>
using std::cout;
struct Address { std::string city; Address(std::string c) : city(c) { cout << "Address "; } ~Address() { cout << "~Address "; } };
struct Course  { std::string title; Course(std::string t) : title(t) { cout << "Course "; } ~Course() { cout << "~Course "; } };
struct Person {
    std::string name; Address addr;
    Person(std::string n, std::string c) : name(n), addr(c) { cout << "Person "; }
    ~Person() { cout << "~Person "; }
};
struct Student : virtual Person {
    Course course;
    Student(std::string n, std::string c, std::string t) : Person(n, c), course(t) { cout << "Student "; }
    ~Student() { cout << "~Student "; }
};
struct Staff : virtual Person {
    double salary;
    Staff(std::string n, std::string c, double s) : Person(n, c), salary(s) { cout << "Staff "; }
    ~Staff() { cout << "~Staff "; }
};
struct TeachingAssistant : Student, Staff {
    // most-derived class must initialise the virtual base directly
    TeachingAssistant(std::string n, std::string c, std::string t, double s)
        : Person(n, c), Student(n, c, t), Staff(n, c, s) { cout << "TA "; }
    ~TeachingAssistant() { cout << "~TA "; }
};
int main() {
    { cout << "Student: ";  Student s("A", "Salem", "C++"); cout << "| "; } cout << '\n';
    { cout << "Staff: ";    Staff f("B", "Chennai", 1000);  cout << "| "; } cout << '\n';
    { cout << "TA: ";       TeachingAssistant t("C", "Madurai", "OOP", 2000); cout << "| "; } cout << '\n';
    cout << "sizeof(TeachingAssistant) = " << sizeof(TeachingAssistant) << '\n';
}
